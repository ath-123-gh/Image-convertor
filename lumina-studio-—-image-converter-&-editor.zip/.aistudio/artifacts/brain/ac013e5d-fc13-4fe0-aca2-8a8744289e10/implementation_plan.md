# Lumina Studio — High-Precision Client-Side Image Transformation Suite

A luxury, tech-focused static website engineered for instant, zero-latency image format conversion, compression, resizing, color grading, and watermarking — operating 100% locally in the browser with zero server uploads and total privacy.

### User Review & Critical Decisions

> [!IMPORTANT]
> Based on your answers, we are building a dedicated **static website** with a **Dark Mode Luxury & Tech-Focused** aesthetic. All image transformation and format conversion operations will be powered purely client-side through high-performance HTML5 Canvas and modern browser Blob/File APIs.

- **Confirmed Decision 1 (Format Conversion)**: Support seamless conversion across modern and web-standard formats: **WEBP**, **PNG**, **JPEG**, **AVIF**, and **SVG** (vectorized canvas tracer/data container), with adjustable compression and lossless toggles.
- **Confirmed Decision 2 (Client-Side Privacy)**: 100% of image rendering, slicing, color matrix math, and conversion stays on the user's hardware. No images are sent to any remote server.
- **Confirmed Decision 3 (Luxury Dark Tech Aesthetic)**: Deep obsidian canvas (`#090D16`), subtle structural hairline borders (`rgba(255,255,255,0.08)`), high-legibility geometric typography (`Plus Jakarta Sans` / `Outfit` pairing), and electric cyan-emerald micro-accents for precision controls.

---

### 1. Overview & Core Concept

- **What It Does**: Lumina Studio delivers an all-in-one web-based image manipulation workstation. Users can drop or select images to instantly convert formats (PNG/JPG/WEBP/AVIF), compress file sizes with real-time before/after comparison sliders, crop to standard aspect ratios (social media, widescreen, custom), apply non-destructive color filters (exposure, contrast, saturation, sharpness), and stamp custom typography watermarks.
- **Target Audience / Persona**: Designers, developers, content creators, and photographers requiring fast, frictionless format shifts and compression without installing heavy software or risking confidential graphics on suspicious cloud conversion sites.
- **Key Value**: Instant conversions without queue limits, zero bandwidth consumption for uploads, and enterprise-grade privacy protection.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Drop & Detect (Hero Zone)**: The user drops single or multiple images onto a high-tactile drag-and-drop zone. The app detects file format, dimensions, pixel aspect, and byte size.
2. **Interactive Workspace Tabs**:
   - **Format Switcher & Optimizer**: One-click target selection (`PNG`, `JPEG`, `WEBP`, `AVIF`), quality slider (1% to 100%), transparency background fill selector (transparent checkerboard vs matte black/white for JPG), and instant download.
   - **Precision Resizer & Cropper**: Preset aspect ratios (16:9, 4:3, 1:1, 9:16, 21:9), social presets (Instagram Post, Twitter Header, YouTube Thumbnail, LinkedIn Banner), pixel lock (`width × height`), and canvas centering.
   - **Color & Exposure Studio**: Hardware-accelerated sliders for Brightness, Contrast, Saturation, Warmth, Sepia, Grayscale, Blur, and Invert with instant reset.
   - **Watermark & Annotation**: Custom text stamp with live opacity, font size, position anchors (9-point matrix: top-left, center, bottom-right, etc.), and padding.
3. **Interactive Comparison Slider**: A split-screen before/after curtain allowing users to visually inspect compression artifacts or color grade adjustments in real-time.
4. **Batch Queue & Export**: Preview file size savings in tabular figures (`tabular-nums`) with individual or bulk ZIP download options.

#### Visual Identity & Theme
- **Aesthetic Direction**: Dark luxury and technical precision. Minimalist geometry, tactile controls, optical clarity, and zero cartoonish candy badges or clunky pill tags.
- **Color Palette & Distribution (60-30-10 Rule)**:
  - `60% Neutral Canvas`: Deep Obsidian (`#090D16`) and Midnight Slate (`#0B0F19`).
  - `30% Structural Surfaces`: Frosted charcoal containers (`#131B2E` with `rgba(255,255,255,0.06)` hairline borders), subtle dividers, and muted secondary typography (`#94A3B8`).
  - `10% Accent Intent`: Precision Lumina Cyan (`#06B6D4` / `#22D3EE`) for active tool modes, primary action buttons, and drag-over indicators.
- **Typography & Hierarchy**:
  - Display & Headings: `Plus Jakarta Sans` in tight tracking (`tracking-tight`) with `text-wrap: balance`.
  - Body & Controls: `DM Sans` or system geometric sans for maximum crispness at 14px–16px.
  - Telemetry & Measurements: Tabular figures (`font-mono tabular-nums text-xs`) for resolution dimensions (`1920 × 1080`), file sizes (`2.4 MB → 410 KB`), and compression percentage (`-83%`).
- **Top Bar Contract**:
  - Zone 1 (Brand): Single clean text wordmark `Lumina Studio` in bold display face with no badges.
  - Zone 2 (Nav Links): `Converter`, `Studio Tools`, `Compression`, `Privacy`, `Specs` (`whitespace-nowrap shrink-0` links).
  - Zone 3 (Primary Action): 1 distinct CTA button: `"Launch Studio"`.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Pure Client-Side Canvas Engine vs. Server-Side Transcoding**
  - *Chosen Approach*: Execute all conversions and filters directly in the browser via `OffscreenCanvas`, `HTMLCanvasElement.toBlob()`, and modern image format encoders.
  - *Why*: Sub-millisecond latency, zero server bandwidth costs, unlimited file sizes up to device memory, and absolute privacy since user assets never leave local memory.
  - *Alternatives Considered*: Server API via Node `sharp`. Rejected because it introduces upload latency, bandwidth limits, privacy concerns, and potential server bottlenecks.

- **Decision 2: Unified Interactive Workspace vs. Separate Page Routing**
  - *Chosen Approach*: A cohesive single-page application with a dynamic workstation hero and quick-switch tool selector, paired with an informative editorial landing flow below the fold explaining capabilities, format compatibility matrices, and privacy architecture.
  - *Why*: Eliminates context loss during multi-step edits (e.g., resizing first, then converting format, then applying watermark).

- **Decision 3: Non-Destructive State Management**
  - *Chosen Approach*: Retain the original file `ImageBitmap` / `ImageData` in memory and apply transformations as a declarative pipeline to a working canvas buffer.
  - *Why*: Allows instantaneous resetting, switching target formats, or tweaking compression quality sliders without lossy generation degradation.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Top Bar (Brand / Nav / CTA)                     │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│              Hero & Live Drop Zone (File Ingestion)                    │
│   - Drag-and-drop files or click to browse                             │
│   - Instant metadata parsing (Dimensions, MIME, Byte Size)             │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                    Lumina Image Studio Workspace                       │
│ ┌─────────────────────────┐  ┌───────────────────────────────────────┐ │
│ │ Tool Selector Sidebar   │  │ Interactive Viewport Canvas           │ │
│ │ - Format Converter      │  │ - Split-View Before/After Slider      │ │
│ │ - Dimensions & Resize   │  │ - Real-time Rendering (Canvas 2D)     │ │
│ │ - Filters & Color Grade │  │ - Resolution & Zoom Controls          │ │
│ │ - Watermark & Stamp     │  │ - Dimension HUD Overlay               │ │
│ └─────────────────────────┘  └───────────────────────────────────────┘ │
│ ┌────────────────────────────────────────────────────────────────────┐ │
│ │ Parameters Control Dock & Batch Queue                              │ │
│ │ - Target format pills / Quality % / Aspect Presets                 │ │
│ │ - Live size calculation (KB/MB) & Savings Delta                    │ │
│ │ - Export Single / Export All (ZIP / Direct Download)               │ │
│ └────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│          Technical Showcase, Format Matrix & Privacy Architecture      │
│   - Supported Formats Grid (WebP, AVIF, PNG, JPEG, SVG)                │
│   - Client-side Security & Zero-Telemetry Guarantee                   │
│   - Interactive FAQ & Performance Benchmarks                           │
└────────────────────────────────────────────────────────────────────────┘
```

#### Core Data State Model
- `ActiveImageState`:
  - `id`: unique file identifier
  - `originalFile`: File object
  - `originalUrl`: object URL
  - `originalMeta`: `{ width: number, height: number, sizeBytes: number, format: string }`
  - `transformState`:
    - `targetFormat`: `'image/webp' | 'image/png' | 'image/jpeg' | 'image/avif'`
    - `quality`: `number` (0.01 to 1.0)
    - `resize`: `{ mode: 'custom' | 'preset', width: number, height: number, lockAspect: boolean }`
    - `filters`: `{ brightness: number, contrast: number, saturation: number, grayscale: number, sepia: number, blur: number, invert: number }`
    - `watermark`: `{ text: string, opacity: number, position: 'center' | 'bottom-right' | 'top-left' | ..., fontSize: number, color: string }`
  - `processedBlob`: Blob | null
  - `processedSize`: number
  - `isProcessing`: boolean
