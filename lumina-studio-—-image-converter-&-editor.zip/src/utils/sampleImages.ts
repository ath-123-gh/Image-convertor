export interface SampleImageDef {
  id: string;
  name: string;
  tagline: string;
  generateFile: () => Promise<File>;
}

/**
 * Creates high-fidelity canvas graphics and exports them as File objects
 */
function createProceduralFile(
  width: number,
  height: number,
  filename: string,
  drawFn: (ctx: CanvasRenderingContext2D, w: number, h: number) => void
): Promise<File> {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      reject(new Error('Failed to get canvas context'));
      return;
    }

    drawFn(ctx, width, height);

    canvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error('Failed to convert canvas to blob'));
        return;
      }
      const file = new File([blob], filename, { type: 'image/png' });
      resolve(file);
    }, 'image/png');
  });
}

export const SAMPLE_IMAGES: SampleImageDef[] = [
  {
    id: 'sample-architecture',
    name: 'obsidian-pavilion-1920x1080.png',
    tagline: 'Architectural Minimalist (1920 × 1080)',
    generateFile: () =>
      createProceduralFile(1920, 1080, 'obsidian-pavilion-1920x1080.png', (ctx, w, h) => {
        // Deep twilight sky gradient
        const skyGrad = ctx.createLinearGradient(0, 0, 0, h);
        skyGrad.addColorStop(0, '#060810');
        skyGrad.addColorStop(0.5, '#0E1726');
        skyGrad.addColorStop(1, '#1A233A');
        ctx.fillStyle = skyGrad;
        ctx.fillRect(0, 0, w, h);

        // Ambient celestial warmth
        const sunGrad = ctx.createRadialGradient(w * 0.75, h * 0.45, 10, w * 0.75, h * 0.45, 500);
        sunGrad.addColorStop(0, 'rgba(245, 158, 11, 0.4)');
        sunGrad.addColorStop(0.4, 'rgba(217, 70, 239, 0.15)');
        sunGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = sunGrad;
        ctx.fillRect(0, 0, w, h);

        // Horizon line & misty ground
        const groundGrad = ctx.createLinearGradient(0, h * 0.65, 0, h);
        groundGrad.addColorStop(0, '#0A0E17');
        groundGrad.addColorStop(1, '#05070B');
        ctx.fillStyle = groundGrad;
        ctx.fillRect(0, h * 0.65, w, h * 0.35);

        // Minimalist architectural structure
        ctx.save();
        // Left monolithic cantilever
        ctx.fillStyle = '#111827';
        ctx.beginPath();
        ctx.moveTo(w * 0.1, h * 0.72);
        ctx.lineTo(w * 0.45, h * 0.42);
        ctx.lineTo(w * 0.58, h * 0.42);
        ctx.lineTo(w * 0.52, h * 0.72);
        ctx.closePath();
        ctx.fill();

        // Glass illuminated facade
        const glassGrad = ctx.createLinearGradient(w * 0.35, h * 0.45, w * 0.5, h * 0.7);
        glassGrad.addColorStop(0, 'rgba(34, 211, 238, 0.6)');
        glassGrad.addColorStop(0.5, 'rgba(14, 165, 233, 0.3)');
        glassGrad.addColorStop(1, 'rgba(2, 132, 199, 0.7)');
        ctx.fillStyle = glassGrad;
        ctx.beginPath();
        ctx.moveTo(w * 0.28, h * 0.68);
        ctx.lineTo(w * 0.48, h * 0.46);
        ctx.lineTo(w * 0.58, h * 0.46);
        ctx.lineTo(w * 0.48, h * 0.68);
        ctx.closePath();
        ctx.fill();

        // Architectural mullions & geometric precision grid
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
        ctx.lineWidth = 2;
        for (let i = 0; i < 8; i++) {
          const t = i / 8;
          ctx.beginPath();
          ctx.moveTo(w * (0.28 + t * 0.2), h * (0.68 - t * 0.22));
          ctx.lineTo(w * (0.38 + t * 0.2), h * (0.68 - t * 0.22));
          ctx.stroke();
        }

        // Right monolith pillar
        ctx.fillStyle = '#0F172A';
        ctx.fillRect(w * 0.65, h * 0.35, w * 0.22, h * 0.38);

        // Warm interior window slit
        ctx.fillStyle = '#FBBF24';
        ctx.shadowColor = '#F59E0B';
        ctx.shadowBlur = 30;
        ctx.fillRect(w * 0.68, h * 0.42, w * 0.04, h * 0.24);
        ctx.shadowBlur = 0;

        // Ground water reflection ripples
        ctx.strokeStyle = 'rgba(34, 211, 238, 0.15)';
        ctx.lineWidth = 1.5;
        for (let y = h * 0.74; y < h; y += 22) {
          ctx.beginPath();
          ctx.moveTo(w * 0.15, y);
          ctx.lineTo(w * 0.85, y);
          ctx.stroke();
        }

        // Typographic overlay watermark for calibration
        ctx.font = '700 24px monospace';
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.fillText('LUMINA ARCHITECTURAL CALIBRATION · 1920×1080 · 60 FPS REFERENCE', 48, h - 48);
        ctx.restore();
      }),
  },
  {
    id: 'sample-cyber',
    name: 'cyber-neural-matrix-1920x1080.png',
    tagline: 'Cyber Neural Grid (1920 × 1080)',
    generateFile: () =>
      createProceduralFile(1920, 1080, 'cyber-neural-matrix-1920x1080.png', (ctx, w, h) => {
        // Deep obsidian canvas
        ctx.fillStyle = '#07090E';
        ctx.fillRect(0, 0, w, h);

        // Perspective grid lines
        const vanishingX = w * 0.5;
        const vanishingY = h * 0.35;

        // Radial glow at horizon
        const glow = ctx.createRadialGradient(vanishingX, vanishingY, 0, vanishingX, vanishingY, 400);
        glow.addColorStop(0, 'rgba(6, 182, 212, 0.5)');
        glow.addColorStop(0.5, 'rgba(16, 185, 129, 0.2)');
        glow.addColorStop(1, 'transparent');
        ctx.fillStyle = glow;
        ctx.fillRect(0, 0, w, h);

        // Grid floor rays
        ctx.strokeStyle = 'rgba(34, 211, 238, 0.25)';
        ctx.lineWidth = 1.5;
        for (let x = -w * 0.5; x <= w * 1.5; x += 100) {
          ctx.beginPath();
          ctx.moveTo(vanishingX, vanishingY);
          ctx.lineTo(x, h);
          ctx.stroke();
        }

        // Horizontal perspective floor lines
        for (let i = 1; i <= 16; i++) {
          const y = vanishingY + Math.pow(i / 16, 2.2) * (h - vanishingY);
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
          ctx.stroke();
        }

        // Floating circuit geometric nodes
        const nodes = [
          { x: w * 0.3, y: h * 0.25, r: 8, color: '#22D3EE' },
          { x: w * 0.7, y: h * 0.2, r: 12, color: '#10B981' },
          { x: w * 0.5, y: h * 0.18, r: 10, color: '#38BDF8' },
          { x: w * 0.4, y: h * 0.5, r: 16, color: '#06B6D4' },
          { x: w * 0.65, y: h * 0.55, r: 14, color: '#34D399' },
        ];

        // Draw connections
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < nodes.length; i++) {
          for (let j = i + 1; j < nodes.length; j++) {
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
          }
        }
        ctx.stroke();

        // Draw glowing nodes
        for (const node of nodes) {
          ctx.save();
          ctx.fillStyle = node.color;
          ctx.shadowColor = node.color;
          ctx.shadowBlur = 20;
          ctx.beginPath();
          ctx.arc(node.x, node.y, node.r, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }

        ctx.font = '600 22px monospace';
        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.fillText('QUANTUM MATRIX CORE // OPTICAL SAMPLING BENCHMARK', 48, h - 48);
      }),
  },
  {
    id: 'sample-chronograph',
    name: 'chronograph-watch-macro-1400x1400.png',
    tagline: 'Chronograph Timepiece (1400 × 1400)',
    generateFile: () =>
      createProceduralFile(1400, 1400, 'chronograph-watch-macro-1400x1400.png', (ctx, w, h) => {
        const cx = w / 2;
        const cy = h / 2;

        // Dark slate studio background
        const bgGrad = ctx.createRadialGradient(cx, cy, 100, cx, cy, 700);
        bgGrad.addColorStop(0, '#131A29');
        bgGrad.addColorStop(1, '#07090F');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, w, h);

        // Watch Bezel Outer Ring
        ctx.save();
        const bezelGrad = ctx.createLinearGradient(cx - 500, cy - 500, cx + 500, cy + 500);
        bezelGrad.addColorStop(0, '#334155');
        bezelGrad.addColorStop(0.5, '#0F172A');
        bezelGrad.addColorStop(1, '#475569');
        ctx.fillStyle = bezelGrad;
        ctx.beginPath();
        ctx.arc(cx, cy, 480, 0, Math.PI * 2);
        ctx.fill();

        // Dial Face (Matte Obsidian)
        const dialGrad = ctx.createRadialGradient(cx, cy, 50, cx, cy, 420);
        dialGrad.addColorStop(0, '#1E293B');
        dialGrad.addColorStop(1, '#090D16');
        ctx.fillStyle = dialGrad;
        ctx.beginPath();
        ctx.arc(cx, cy, 420, 0, Math.PI * 2);
        ctx.fill();

        // Bezel Minute Markers
        for (let i = 0; i < 60; i++) {
          const angle = (i * Math.PI * 2) / 60;
          const isMajor = i % 5 === 0;
          const r1 = 410;
          const r2 = isMajor ? 375 : 395;
          ctx.strokeStyle = isMajor ? '#E2E8F0' : 'rgba(148, 163, 184, 0.5)';
          ctx.lineWidth = isMajor ? 3.5 : 1.5;
          ctx.beginPath();
          ctx.moveTo(cx + Math.cos(angle) * r1, cy + Math.sin(angle) * r1);
          ctx.lineTo(cx + Math.cos(angle) * r2, cy + Math.sin(angle) * r2);
          ctx.stroke();
        }

        // Subdial Left (Seconds)
        ctx.fillStyle = '#0B0F19';
        ctx.beginPath();
        ctx.arc(cx - 160, cy, 110, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Subdial Right (Minutes)
        ctx.beginPath();
        ctx.arc(cx + 160, cy, 110, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Hands (Titanium & Lumina Cyan Accent)
        // Hour Hand
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate((-35 * Math.PI) / 180);
        ctx.fillStyle = '#F8FAFC';
        ctx.fillRect(-6, -220, 12, 220);
        ctx.restore();

        // Minute Hand
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate((68 * Math.PI) / 180);
        ctx.fillStyle = '#E2E8F0';
        ctx.fillRect(-4, -310, 8, 310);
        ctx.restore();

        // Chrono Second Hand (Cyan accent)
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate((195 * Math.PI) / 180);
        ctx.fillStyle = '#22D3EE';
        ctx.shadowColor = '#06B6D4';
        ctx.shadowBlur = 10;
        ctx.fillRect(-2, -340, 4, 390);
        ctx.beginPath();
        ctx.arc(0, 0, 10, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Brand inscription on dial
        ctx.font = '700 20px "Plus Jakarta Sans", sans-serif';
        ctx.fillStyle = '#F1F5F9';
        ctx.textAlign = 'center';
        ctx.fillText('LUMINA CHRONOGRAPH', cx, cy - 140);
        ctx.font = '500 13px monospace';
        ctx.fillStyle = '#64748B';
        ctx.fillText('300M / 1000FT · AUTOMATIC', cx, cy - 115);

        ctx.restore();
      }),
  },
];
