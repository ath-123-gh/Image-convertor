import { ProcessedItem, SupportedFormat, TransformSettings, FormatSpec } from '../types/image';
import JSZip from 'jszip';

export const SUPPORTED_FORMAT_SPECS: FormatSpec[] = [
  {
    format: 'image/webp',
    extension: 'webp',
    label: 'WEBP',
    fullName: 'WebP Image',
    description: 'Modern web standard developed by Google. Delivers 25–35% smaller sizes than JPEG with alpha transparency.',
    transparency: true,
    losslessSupport: true,
    compressionEfficiency: 'High (~30% smaller than JPEG)',
    recommendedUse: 'Websites, hero assets, digital graphics, social media.',
    browserSupport: '97%+ (All modern browsers)',
  },
  {
    format: 'image/png',
    extension: 'png',
    label: 'PNG',
    fullName: 'Portable Network Graphics',
    description: 'Lossless standard for graphics requiring pristine transparency, sharp typography, and vector-like fidelity.',
    transparency: true,
    losslessSupport: true,
    compressionEfficiency: 'Lossless (Larger file sizes)',
    recommendedUse: 'Logos, icons, charts, transparent overlays, UI screenshots.',
    browserSupport: '100% (Universal)',
  },
  {
    format: 'image/jpeg',
    extension: 'jpg',
    label: 'JPEG',
    fullName: 'Joint Photographic Experts Group',
    description: 'Universal standard for photographic imagery. Highly compatible across all devices, email clients, and print.',
    transparency: false,
    losslessSupport: false,
    compressionEfficiency: 'Standard lossy compression',
    recommendedUse: 'Photographs, blog editorial images, legacy compatibility.',
    browserSupport: '100% (Universal)',
  },
  {
    format: 'image/avif',
    extension: 'avif',
    label: 'AVIF',
    fullName: 'AV1 Image File Format',
    description: 'Cutting-edge next-generation format with superior HDR preservation and up to 50% smaller sizes than JPEG.',
    transparency: true,
    losslessSupport: true,
    compressionEfficiency: 'Ultra-High (~50% smaller than JPEG)',
    recommendedUse: 'High-traffic websites, mobile applications, bandwidth conservation.',
    browserSupport: '93%+ (Chrome, Firefox, Safari 16+)',
  },
  {
    format: 'image/svg+xml',
    extension: 'svg',
    label: 'SVG',
    fullName: 'Scalable Vector Graphics Container',
    description: 'Vector XML wrapper that embeds high-resolution raster imagery into an infinitely scalable SVG container.',
    transparency: true,
    losslessSupport: true,
    compressionEfficiency: 'Vector container representation',
    recommendedUse: 'Embedding in Figma, Illustrator, web vector systems, icon slots.',
    browserSupport: '100% (Universal)',
  },
];

export function formatBytes(bytes: number, decimals = 1): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

export function calculateSizeDelta(original: number, processed: number): {
  percent: number;
  saved: boolean;
  text: string;
} {
  if (original <= 0 || processed <= 0) {
    return { percent: 0, saved: false, text: '0%' };
  }
  const diff = original - processed;
  const percent = Math.round((diff / original) * 100);
  if (percent > 0) {
    return { percent, saved: true, text: `-${percent}%` };
  } else if (percent < 0) {
    return { percent: Math.abs(percent), saved: false, text: `+${Math.abs(percent)}%` };
  }
  return { percent: 0, saved: false, text: '0%' };
}

export function getDefaultTransformSettings(
  width: number,
  height: number,
  originalMime: string
): TransformSettings {
  // Suggest WebP as default for modern efficiency unless user is already uploading SVG
  const defaultFormat: SupportedFormat =
    originalMime === 'image/webp' ? 'image/webp' : 'image/webp';

  return {
    targetFormat: defaultFormat,
    quality: 85,
    resizeWidth: width,
    resizeHeight: height,
    lockAspectRatio: true,
    aspectPreset: 'original',
    rotation: 0,
    flipH: false,
    flipV: false,
    borderRadius: 0,
    bgColor: originalMime === 'image/jpeg' ? '#FFFFFF' : 'transparent',
    filters: {
      brightness: 100,
      contrast: 100,
      saturation: 100,
      grayscale: 0,
      sepia: 0,
      blur: 0,
      invert: 0,
      hueRotate: 0,
    },
    watermark: {
      enabled: false,
      text: 'LUMINA STUDIO',
      fontSize: 28,
      opacity: 70,
      color: '#FFFFFF',
      position: 'bottom-right',
    },
  };
}

/**
 * Loads an image from a source URL cleanly with CORS handling
 */
export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(new Error('Failed to load image: ' + err));
    img.src = src;
  });
}

/**
 * Executes high-performance client-side rendering pipeline
 */
export async function processImageTransformation(
  item: ProcessedItem
): Promise<{
  blob: Blob;
  url: string;
  width: number;
  height: number;
  size: number;
}> {
  const img = await loadImage(item.originalUrl);
  const settings = item.settings;

  // Determine canvas dimensions
  const targetWidth = Math.max(1, Math.round(settings.resizeWidth || img.naturalWidth));
  const targetHeight = Math.max(1, Math.round(settings.resizeHeight || img.naturalHeight));

  const isRotated90or270 = settings.rotation === 90 || settings.rotation === 270;
  const canvasWidth = isRotated90or270 ? targetHeight : targetWidth;
  const canvasHeight = isRotated90or270 ? targetWidth : targetHeight;

  const canvas = document.createElement('canvas');
  canvas.width = canvasWidth;
  canvas.height = canvasHeight;

  const ctx = canvas.getContext('2d', { willReadFrequently: false });
  if (!ctx) {
    throw new Error('Canvas 2D context not available');
  }

  // Smooth rendering setup
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // Background Fill (e.g. for transparent PNG to JPEG or custom background)
  if (settings.targetFormat === 'image/jpeg' || settings.bgColor !== 'transparent') {
    ctx.fillStyle = settings.bgColor === 'transparent' ? '#FFFFFF' : settings.bgColor;
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
  }

  // Optional rounded corners clipping
  if (settings.borderRadius > 0) {
    const r = Math.min(settings.borderRadius, canvasWidth / 2, canvasHeight / 2);
    ctx.beginPath();
    ctx.moveTo(r, 0);
    ctx.lineTo(canvasWidth - r, 0);
    ctx.quadraticCurveTo(canvasWidth, 0, canvasWidth, r);
    ctx.lineTo(canvasWidth, canvasHeight - r);
    ctx.quadraticCurveTo(canvasWidth, canvasHeight, canvasWidth - r, canvasHeight);
    ctx.lineTo(r, canvasHeight);
    ctx.quadraticCurveTo(0, canvasHeight, 0, canvasHeight - r);
    ctx.lineTo(0, r);
    ctx.quadraticCurveTo(0, 0, r, 0);
    ctx.closePath();
    ctx.clip();
  }

  ctx.save();

  // Handle position & rotation transformations
  ctx.translate(canvasWidth / 2, canvasHeight / 2);

  if (settings.rotation !== 0) {
    ctx.rotate((settings.rotation * Math.PI) / 180);
  }

  ctx.scale(settings.flipH ? -1 : 1, settings.flipV ? -1 : 1);

  // Apply filters via hardware-accelerated CSS filter string
  const f = settings.filters;
  ctx.filter = `brightness(${f.brightness}%) contrast(${f.contrast}%) saturate(${f.saturation}%) grayscale(${f.grayscale}%) sepia(${f.sepia}%) invert(${f.invert}%) blur(${f.blur}px) hue-rotate(${f.hueRotate}deg)`;

  // Draw scaled image centered
  ctx.drawImage(img, -targetWidth / 2, -targetHeight / 2, targetWidth, targetHeight);

  ctx.restore();

  // Watermark Layer
  if (settings.watermark.enabled && settings.watermark.text.trim()) {
    ctx.save();
    const wm = settings.watermark;
    const padding = Math.max(16, Math.round(canvasWidth * 0.03));
    ctx.font = `600 ${wm.fontSize}px 'Plus Jakarta Sans', system-ui, sans-serif`;
    ctx.globalAlpha = Math.max(0.1, Math.min(1, wm.opacity / 100));
    ctx.fillStyle = wm.color;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetX = 1;
    ctx.shadowOffsetY = 1;

    const textMetrics = ctx.measureText(wm.text);
    const textWidth = textMetrics.width;
    const textHeight = wm.fontSize;

    let x = padding;
    let y = padding + textHeight;

    switch (wm.position) {
      case 'top-left':
        x = padding;
        y = padding + textHeight;
        break;
      case 'top-center':
        x = (canvasWidth - textWidth) / 2;
        y = padding + textHeight;
        break;
      case 'top-right':
        x = canvasWidth - textWidth - padding;
        y = padding + textHeight;
        break;
      case 'center-left':
        x = padding;
        y = canvasHeight / 2 + textHeight / 3;
        break;
      case 'center':
        x = (canvasWidth - textWidth) / 2;
        y = canvasHeight / 2 + textHeight / 3;
        break;
      case 'center-right':
        x = canvasWidth - textWidth - padding;
        y = canvasHeight / 2 + textHeight / 3;
        break;
      case 'bottom-left':
        x = padding;
        y = canvasHeight - padding;
        break;
      case 'bottom-center':
        x = (canvasWidth - textWidth) / 2;
        y = canvasHeight - padding;
        break;
      case 'bottom-right':
        x = canvasWidth - textWidth - padding;
        y = canvasHeight - padding;
        break;
    }

    ctx.fillText(wm.text, x, y);
    ctx.restore();
  }

  // Target format encoding
  if (settings.targetFormat === 'image/svg+xml') {
    // Generate clean SVG wrapper with embedded high-quality data URL
    const pngDataUrl = canvas.toDataURL('image/png');
    const svgContent = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${canvasWidth} ${canvasHeight}" width="${canvasWidth}" height="${canvasHeight}">
  <title>${item.name.replace(/\.[^/.]+$/, '')}</title>
  <image width="${canvasWidth}" height="${canvasHeight}" xlink:href="${pngDataUrl}" />
</svg>`;
    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    return {
      blob,
      url,
      width: canvasWidth,
      height: canvasHeight,
      size: blob.size,
    };
  }

  // Canvas toBlob for standard formats
  const qualityDecimal = Math.max(0.01, Math.min(1.0, settings.quality / 100));

  return new Promise((resolve, reject) => {
    // Try requested format with quality parameter
    canvas.toBlob(
      (blob) => {
        if (!blob) {
          // Fallback to webp or png if browser does not support experimental format encoding (e.g. AVIF in older browser)
          canvas.toBlob(
            (fallbackBlob) => {
              if (!fallbackBlob) {
                reject(new Error('Failed to encode image canvas to blob'));
                return;
              }
              const url = URL.createObjectURL(fallbackBlob);
              resolve({
                blob: fallbackBlob,
                url,
                width: canvasWidth,
                height: canvasHeight,
                size: fallbackBlob.size,
              });
            },
            'image/webp',
            qualityDecimal
          );
          return;
        }

        const url = URL.createObjectURL(blob);
        resolve({
          blob,
          url,
          width: canvasWidth,
          height: canvasHeight,
          size: blob.size,
        });
      },
      settings.targetFormat,
      qualityDecimal
    );
  });
}

/**
 * Triggers a download of a blob with a clean sanitized filename
 */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 15000);
}

/**
 * Generates an export filename based on original name and target format
 */
export function getExportFilename(originalName: string, targetFormat: SupportedFormat): string {
  const base = originalName.replace(/\.[^/.]+$/, '');
  const spec = SUPPORTED_FORMAT_SPECS.find((s) => s.format === targetFormat);
  const ext = spec ? spec.extension : 'webp';
  return `${base}-lumina.${ext}`;
}

/**
 * Bundles multiple processed items into a single zip file for instant download
 */
export async function exportAllAsZip(items: ProcessedItem[], zipName = 'lumina-studio-exports.zip'): Promise<void> {
  const zip = new JSZip();

  for (const item of items) {
    if (item.processedBlob) {
      const filename = getExportFilename(item.name, item.settings.targetFormat);
      zip.file(filename, item.processedBlob);
    }
  }

  const zipContent = await zip.generateAsync({ type: 'blob' });
  downloadBlob(zipContent, zipName);
}
