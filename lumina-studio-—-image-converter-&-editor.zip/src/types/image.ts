export type SupportedFormat = 
  | 'image/webp'
  | 'image/png'
  | 'image/jpeg'
  | 'image/avif'
  | 'image/svg+xml';

export type AspectRatioPreset = 
  | 'original'
  | '1:1'
  | '16:9'
  | '4:3'
  | '9:16'
  | '21:9'
  | 'ig-post'       // 1080 x 1080
  | 'ig-story'      // 1080 x 1920
  | 'yt-thumbnail'  // 1280 x 720
  | 'twitter-hdr'   // 1500 x 500
  | 'linkedin-bnr'; // 1584 x 396

export type WatermarkPosition = 
  | 'top-left'
  | 'top-center'
  | 'top-right'
  | 'center-left'
  | 'center'
  | 'center-right'
  | 'bottom-left'
  | 'bottom-center'
  | 'bottom-right';

export interface ImageFilters {
  brightness: number;  // 100 is default (%)
  contrast: number;    // 100 is default (%)
  saturation: number;  // 100 is default (%)
  grayscale: number;   // 0 is default (%)
  sepia: number;       // 0 is default (%)
  blur: number;        // 0 is default (px)
  invert: number;      // 0 is default (%)
  hueRotate: number;   // 0 is default (deg)
}

export interface WatermarkConfig {
  enabled: boolean;
  text: string;
  fontSize: number;
  opacity: number;
  color: string;
  position: WatermarkPosition;
}

export interface TransformSettings {
  targetFormat: SupportedFormat;
  quality: number; // 1 to 100
  resizeWidth: number;
  resizeHeight: number;
  lockAspectRatio: boolean;
  aspectPreset: AspectRatioPreset;
  rotation: number; // 0, 90, 180, 270
  flipH: boolean;
  flipV: boolean;
  borderRadius: number; // 0 to 200
  bgColor: string; // for transparent PNG to JPEG (e.g. '#000000', '#ffffff', or 'transparent')
  filters: ImageFilters;
  watermark: WatermarkConfig;
}

export interface ProcessedItem {
  id: string;
  name: string;
  originalFile: File;
  originalUrl: string;
  originalWidth: number;
  originalHeight: number;
  originalSize: number;
  originalFormat: string;
  settings: TransformSettings;
  processedBlob: Blob | null;
  processedUrl: string | null;
  processedWidth: number;
  processedHeight: number;
  processedSize: number;
  isProcessing: boolean;
  error: string | null;
}

export interface FormatSpec {
  format: SupportedFormat;
  extension: string;
  label: string;
  fullName: string;
  description: string;
  transparency: boolean;
  losslessSupport: boolean;
  compressionEfficiency: string;
  recommendedUse: string;
  browserSupport: string;
}
