/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { StudioWorkspace } from './components/StudioWorkspace';
import { FeaturesShowcase } from './components/FeaturesShowcase';
import { FormatMatrixSection } from './components/FormatMatrixSection';
import { PrivacySection } from './components/PrivacySection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { ProcessedItem } from './types/image';
import {
  getDefaultTransformSettings,
  processImageTransformation,
  loadImage,
} from './utils/imageProcessor';
import { SAMPLE_IMAGES } from './utils/sampleImages';

export default function App() {
  const [items, setItems] = useState<ProcessedItem[]>([]);
  const [activeId, setActiveId] = useState<string>('');
  const [isLoadingSample, setIsLoadingSample] = useState<boolean>(false);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Ingest new file objects
  const ingestFiles = useCallback(async (files: File[]) => {
    const newItems: ProcessedItem[] = [];

    for (const file of files) {
      const id = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      const originalUrl = URL.createObjectURL(file);

      try {
        const img = await loadImage(originalUrl);
        const originalWidth = img.naturalWidth;
        const originalHeight = img.naturalHeight;
        const defaultSettings = getDefaultTransformSettings(
          originalWidth,
          originalHeight,
          file.type
        );

        const tempItem: ProcessedItem = {
          id,
          name: file.name,
          originalFile: file,
          originalUrl,
          originalWidth,
          originalHeight,
          originalSize: file.size,
          originalFormat: file.type || 'image/png',
          settings: defaultSettings,
          processedBlob: null,
          processedUrl: null,
          processedWidth: originalWidth,
          processedHeight: originalHeight,
          processedSize: 0,
          isProcessing: true,
          error: null,
        };

        // Run initial transformation
        const result = await processImageTransformation(tempItem);

        tempItem.processedBlob = result.blob;
        tempItem.processedUrl = result.url;
        tempItem.processedWidth = result.width;
        tempItem.processedHeight = result.height;
        tempItem.processedSize = result.size;
        tempItem.isProcessing = false;

        newItems.push(tempItem);
      } catch (err) {
        console.error('Error ingesting file:', err);
      }
    }

    if (newItems.length > 0) {
      setItems((prev) => [...prev, ...newItems]);
      setActiveId(newItems[0].id);

      // Smooth scroll to workspace
      setTimeout(() => {
        const workspaceEl = document.getElementById('workspace');
        if (workspaceEl) {
          workspaceEl.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  }, []);

  // Handle sample image click
  const handleSelectSample = async (sampleId: string) => {
    const sampleDef = SAMPLE_IMAGES.find((s) => s.id === sampleId);
    if (!sampleDef) return;

    setIsLoadingSample(true);
    try {
      const file = await sampleDef.generateFile();
      await ingestFiles([file]);
    } catch (err) {
      console.error('Failed to load sample image:', err);
    } finally {
      setIsLoadingSample(false);
    }
  };

  // Pre-load default sample on initial mount if queue is empty
  useEffect(() => {
    if (items.length === 0) {
      handleSelectSample('sample-architecture');
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Process item updates with debounce
  const updateSettings = useCallback(
    (id: string, updater: (prev: ProcessedItem) => ProcessedItem) => {
      setItems((prevItems) => {
        const targetIndex = prevItems.findIndex((item) => item.id === id);
        if (targetIndex === -1) return prevItems;

        const updated = updater(prevItems[targetIndex]);
        const copy = [...prevItems];
        copy[targetIndex] = { ...updated, isProcessing: true };

        // Schedule debounce transform
        if (debounceTimerRef.current) {
          clearTimeout(debounceTimerRef.current);
        }

        debounceTimerRef.current = setTimeout(async () => {
          try {
            const res = await processImageTransformation(updated);
            setItems((currentItems) =>
              currentItems.map((item) =>
                item.id === id
                  ? {
                      ...item,
                      processedBlob: res.blob,
                      processedUrl: res.url,
                      processedWidth: res.width,
                      processedHeight: res.height,
                      processedSize: res.size,
                      isProcessing: false,
                    }
                  : item
              )
            );
          } catch (err) {
            console.error('Error processing transformation:', err);
            setItems((currentItems) =>
              currentItems.map((item) =>
                item.id === id
                  ? { ...item, isProcessing: false, error: 'Transformation failed' }
                  : item
              )
            );
          }
        }, 120);

        return copy;
      });
    },
    []
  );

  const removeItem = (id: string) => {
    setItems((prev) => {
      const next = prev.filter((item) => item.id !== id);
      if (activeId === id && next.length > 0) {
        setActiveId(next[0].id);
      }
      return next;
    });
  };

  const clearAll = () => {
    items.forEach((item) => {
      if (item.originalUrl) URL.revokeObjectURL(item.originalUrl);
      if (item.processedUrl) URL.revokeObjectURL(item.processedUrl);
    });
    setItems([]);
    setActiveId('');
  };

  const handleOpenUpload = () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.multiple = true;
    fileInput.accept = 'image/*,.webp,.png,.jpg,.jpeg,.avif,.svg,.bmp';
    fileInput.onchange = (e) => {
      const target = e.target as HTMLInputElement;
      if (target.files && target.files.length > 0) {
        ingestFiles(Array.from(target.files));
      }
    };
    fileInput.click();
  };

  return (
    <div className="min-h-screen bg-[#080B11] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* 3-Zone Top Navigation Contract */}
      <Header onOpenUpload={handleOpenUpload} itemCount={items.length} />

      {/* Main Page Flow */}
      <main className="flex-1">
        {/* Hero Section with Live Drop Ingestion */}
        <Hero
          onFilesSelected={ingestFiles}
          onSelectSample={handleSelectSample}
          isLoadingSample={isLoadingSample}
        />

        {/* Interactive Studio Workspace */}
        {items.length > 0 && (
          <StudioWorkspace
            items={items}
            activeId={activeId}
            onSelectActive={setActiveId}
            onUpdateSettings={updateSettings}
            onRemoveItem={removeItem}
            onClearAll={clearAll}
          />
        )}

        {/* Capabilities Bento Grid */}
        <FeaturesShowcase />

        {/* Format Comparison Specs Matrix */}
        <FormatMatrixSection />

        {/* 100% Client-Side Privacy Architecture */}
        <PrivacySection />

        {/* Frequently Asked Questions */}
        <FaqSection />
      </main>

      {/* Quiet Footer */}
      <Footer />
    </div>
  );
}
