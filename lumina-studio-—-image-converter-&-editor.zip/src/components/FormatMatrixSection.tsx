import React from 'react';
import { SUPPORTED_FORMAT_SPECS } from '../utils/imageProcessor';
import { Check, X } from 'lucide-react';

export const FormatMatrixSection: React.FC = () => {
  return (
    <section id="format-specs" className="py-16 md:py-24 bg-[#090D16] border-b border-slate-800/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mb-12">
          <div className="text-xs font-semibold uppercase tracking-wider text-cyan-400 mb-2 flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
            <span>Technical Specifications</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            Format Comparison & Standard Matrix
          </h2>
          <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
            Understand the architectural differences between modern compression algorithms to pick the optimal format for your specific delivery target.
          </p>
        </div>

        {/* Specs Table */}
        <div className="overflow-x-auto rounded-2xl border border-slate-800/80 bg-[#0E1422] shadow-xl">
          <table className="w-full text-left text-xs sm:text-sm text-slate-300">
            <thead className="border-b border-slate-800 bg-[#0A0F1A] text-xs font-semibold uppercase text-slate-400">
              <tr>
                <th className="px-6 py-4">Format / MIME</th>
                <th className="px-6 py-4">Alpha Transparency</th>
                <th className="px-6 py-4">Lossless Mode</th>
                <th className="px-6 py-4">Compression Profile</th>
                <th className="px-6 py-4">Browser Coverage</th>
                <th className="px-6 py-4">Recommended Scenario</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {SUPPORTED_FORMAT_SPECS.map((spec) => (
                <tr key={spec.format} className="hover:bg-slate-900/40 transition-colors">
                  <td className="px-6 py-4 font-medium text-white whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <span className="inline-block px-2 py-0.5 rounded bg-slate-800 font-mono text-cyan-400 text-xs font-bold">
                        {spec.label}
                      </span>
                      <span className="text-slate-400 text-xs hidden sm:inline">.{spec.extension}</span>
                    </div>
                  </td>

                  <td className="px-6 py-4 whitespace-nowrap">
                    {spec.transparency ? (
                      <span className="inline-flex items-center gap-1.5 text-emerald-400 font-medium">
                        <Check className="h-4 w-4" />
                        <span>Supported</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-slate-500 font-medium">
                        <X className="h-4 w-4" />
                        <span>No (Matte fill)</span>
                      </span>
                    )}
                  </td>

                  <td className="px-6 py-4 whitespace-nowrap">
                    {spec.losslessSupport ? (
                      <span className="inline-flex items-center gap-1.5 text-emerald-400 font-medium">
                        <Check className="h-4 w-4" />
                        <span>Available</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-slate-500 font-medium">
                        <X className="h-4 w-4" />
                        <span>Lossy Only</span>
                      </span>
                    )}
                  </td>

                  <td className="px-6 py-4 text-slate-300 font-medium whitespace-nowrap">
                    {spec.compressionEfficiency}
                  </td>

                  <td className="px-6 py-4 font-mono text-xs text-slate-300 tabular-nums whitespace-nowrap">
                    {spec.browserSupport}
                  </td>

                  <td className="px-6 py-4 text-slate-400 text-xs max-w-xs leading-relaxed">
                    {spec.recommendedUse}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
