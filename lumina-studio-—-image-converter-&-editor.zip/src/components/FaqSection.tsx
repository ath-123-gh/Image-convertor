import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
}

const FAQS: FaqItem[] = [
  {
    question: 'Are my images uploaded to any remote server or stored in the cloud?',
    answer:
      'Never. 100% of image decoding, matrix filtering, cropping, and format encoding occurs entirely inside your web browser memory using HTML5 Canvas and native JavaScript Blob APIs. Not a single pixel is ever uploaded to a remote server or telemetry database.',
  },
  {
    question: 'Which image format should I pick: WebP, AVIF, PNG, or JPEG?',
    answer:
      'For websites and general digital content, WebP is the recommended modern default—it preserves transparency and is 25–35% smaller than JPEG. AVIF offers even deeper compression and HDR reproduction on supported browsers. PNG is optimal when lossless sharpness and transparent graphics (like logos or line art) are mandatory. JPEG is best for legacy compatibility across older software.',
  },
  {
    question: 'How does Lumina Studio handle transparent PNGs converting to JPEG?',
    answer:
      'JPEG does not support alpha transparency channels. Lumina Studio allows you to customize the canvas background matte (solid white, obsidian black, or custom color) so your transparent graphics cleanly composite without unexpected black artifact borders.',
  },
  {
    question: 'Is there a limit on file resolution or number of files in batch queue?',
    answer:
      'There are no arbitrary cloud limits or subscription paywalls. You can process high-resolution camera originals (including 4K, 8K, and 50+ megapixel photos) as well as multiple images simultaneously, limited only by your computer’s RAM and browser memory.',
  },
  {
    question: 'Can I use Lumina Studio offline or without an active internet connection?',
    answer:
      'Yes. Once the web application is loaded in your browser, all transformation algorithms execute locally in JavaScript. You can disconnect your network connection and continue converting, cropping, compressing, and exporting files completely offline.',
  },
];

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-16 md:py-24 bg-[#090D16] border-b border-slate-800/80">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-cyan-400 uppercase mb-2">
            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
            <span>Frequently Asked Questions</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            Everything You Need to Know
          </h2>
          <p className="text-sm text-slate-400">
            Common questions regarding local processing, format compatibility, and compression.
          </p>
        </div>

        <div className="flex flex-col gap-3">
          {FAQS.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="rounded-xl border border-slate-800/80 bg-[#0E1422] transition-colors hover:border-slate-700 overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(idx)}
                  className="flex w-full items-center justify-between p-5 text-left text-sm font-semibold text-white transition-colors"
                >
                  <span>{faq.question}</span>
                  <ChevronDown
                    className={`h-4 w-4 text-cyan-400 transition-transform duration-200 shrink-0 ml-4 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
