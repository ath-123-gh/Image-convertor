import React, { useRef, useState, useEffect } from 'react';
import { Upload, Image as ImageIcon, ShieldCheck, Zap, Sliders, Sparkles } from 'lucide-react';
import { SAMPLE_IMAGES } from '../utils/sampleImages';

interface HeroProps {
  onFilesSelected: (files: File[]) => void;
  onSelectSample: (sampleId: string) => void;
  isLoadingSample: boolean;
}

export const Hero: React.FC<HeroProps> = ({
  onFilesSelected,
  onSelectSample,
  isLoadingSample,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Handle global paste event for quick image drop
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      const imageFiles: File[] = [];
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) imageFiles.push(file);
        }
      }
      if (imageFiles.length > 0) {
        onFilesSelected(imageFiles);
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [onFilesSelected]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files).filter((file) =>
      file.type.startsWith('image/') || file.name.match(/\.(jpg|jpeg|png|webp|avif|svg|bmp|gif)$/i)
    );

    if (files.length > 0) {
      onFilesSelected(files);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      onFilesSelected(files);
      e.target.value = '';
    }
  };

  return (
    <section className="relative overflow-hidden pt-12 pb-16 md:pt-20 md:pb-24 border-b border-slate-800/60 tech-grid-bg">
      {/* Subtle radial spotlight */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[450px] bg-cyan-500/10 blur-[130px] rounded-full pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Editorial Eyebrow & Value Proposition */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-cyan-400 uppercase mb-4">
            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
            <span>Client-Side Processing Engine</span>
            <span className="text-slate-500">·</span>
            <span>Zero Server Latency</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-5 leading-tight [text-wrap:balance]">
            Precision Image Format & Editing Suite
          </h1>

          <p className="text-base sm:text-lg text-slate-400 leading-relaxed max-w-2xl mx-auto">
            Convert formats, compress weight, crop dimensions, and adjust color grades — completely in your browser with zero server uploads and total privacy.
          </p>
        </div>

        {/* Tactical Drag & Drop Ingestion Box */}
        <div className="max-w-3xl mx-auto">
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`group relative cursor-pointer rounded-2xl border-2 border-dashed p-8 sm:p-12 text-center transition-all duration-200 ${
              isDragging
                ? 'border-cyan-400 bg-cyan-950/30 scale-[1.01] shadow-[0_0_30px_rgba(6,182,212,0.25)]'
                : 'border-slate-700/80 bg-[#0D121F]/80 hover:border-cyan-500/60 hover:bg-[#111828]/90'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,.webp,.png,.jpg,.jpeg,.avif,.svg,.bmp"
              onChange={handleFileInputChange}
              className="hidden"
            />

            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-xl bg-slate-800/90 text-cyan-400 transition-transform group-hover:scale-105 border border-slate-700/60">
              <Upload className="h-8 w-8 transition-colors group-hover:text-cyan-300" />
            </div>

            <h3 className="mt-5 text-lg font-semibold text-white">
              {isDragging ? 'Drop images to load instantly' : 'Drop images here or click to browse'}
            </h3>

            <p className="mt-2 text-sm text-slate-400">
              Supports <strong className="text-slate-300 font-medium">PNG, JPEG, WebP, AVIF, SVG, BMP</strong>. Multi-file batch processing supported.
            </p>

            <div className="mt-4 flex items-center justify-center gap-4 text-xs text-slate-400">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1 w-1 rounded-full bg-cyan-400"></span>
                <span>Paste from clipboard (Ctrl+V)</span>
              </span>
              <span className="text-slate-600">·</span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1 w-1 rounded-full bg-cyan-400"></span>
                <span>No file size limits</span>
              </span>
            </div>
          </div>

          {/* Quick Demo Calibration Assets */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
              <span>Or test with demo graphics:</span>
            </span>

            {SAMPLE_IMAGES.map((sample) => (
              <button
                key={sample.id}
                type="button"
                disabled={isLoadingSample}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectSample(sample.id);
                }}
                className="rounded-lg border border-slate-800 bg-slate-900/80 px-3 py-1.5 text-xs font-medium text-slate-300 transition-all hover:border-cyan-500/50 hover:bg-slate-800 hover:text-white disabled:opacity-50 whitespace-nowrap"
              >
                {sample.tagline}
              </button>
            ))}
          </div>

          {/* Trust strip */}
          <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-slate-800/80 pt-6 text-xs text-slate-400">
            <div className="flex items-center justify-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>100% Client-Side Memory</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <Zap className="h-4 w-4 text-cyan-400 shrink-0" />
              <span>Sub-millisecond Canvas Transcoding</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <Sliders className="h-4 w-4 text-indigo-400 shrink-0" />
              <span>Lossless & Perceptual Compression</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
