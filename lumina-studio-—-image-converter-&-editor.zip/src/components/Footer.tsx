import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-slate-800/80 bg-[#06080E] py-12 text-xs text-slate-400">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-slate-800/60">
          <div className="flex items-center gap-2">
            <span className="inline-block h-2 w-2 rounded-sm bg-cyan-400"></span>
            <span className="text-base font-bold text-white tracking-tight">Lumina Studio</span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">Client-Side Image Manipulation Suite</span>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-400">
            <a href="#workspace" className="hover:text-cyan-400 transition-colors">
              Converter
            </a>
            <a href="#workspace" className="hover:text-cyan-400 transition-colors">
              Studio Tools
            </a>
            <a href="#capabilities" className="hover:text-cyan-400 transition-colors">
              Compression
            </a>
            <a href="#format-specs" className="hover:text-cyan-400 transition-colors">
              Format Matrix
            </a>
            <a href="#privacy" className="hover:text-cyan-400 transition-colors">
              Privacy Architecture
            </a>
          </div>
        </div>

        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
          <p>© {new Date().getFullYear()} Lumina Studio. 100% Client-Side. No telemetry or server storage.</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>W3C Canvas 2D</span>
            <span>·</span>
            <span>WebP / AVIF Standard</span>
            <span>·</span>
            <span>Zero Remote Latency</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
