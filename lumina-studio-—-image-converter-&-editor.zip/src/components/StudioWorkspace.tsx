import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  ProcessedItem,
  SupportedFormat,
  AspectRatioPreset,
  WatermarkPosition,
} from '../types/image';
import {
  formatBytes,
  calculateSizeDelta,
  getExportFilename,
  downloadBlob,
  exportAllAsZip,
  SUPPORTED_FORMAT_SPECS,
} from '../utils/imageProcessor';
import {
  Download,
  RotateCw,
  RotateCcw,
  FlipHorizontal,
  FlipVertical,
  Sliders,
  Maximize2,
  Crop,
  Type,
  FileCheck,
  Check,
  Layers,
  Sparkles,
  RefreshCw,
  Copy,
  Archive,
  Trash2,
  Eye,
  Columns,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';

interface StudioWorkspaceProps {
  items: ProcessedItem[];
  activeId: string;
  onSelectActive: (id: string) => void;
  onUpdateSettings: (id: string, updater: (prev: ProcessedItem) => ProcessedItem) => void;
  onRemoveItem: (id: string) => void;
  onClearAll: () => void;
}

type TabKey = 'format' | 'resize' | 'filters' | 'transform' | 'watermark';

export const StudioWorkspace: React.FC<StudioWorkspaceProps> = ({
  items,
  activeId,
  onSelectActive,
  onUpdateSettings,
  onRemoveItem,
  onClearAll,
}) => {
  const activeItem = items.find((i) => i.id === activeId) || items[0];

  const [activeTab, setActiveTab] = useState<TabKey>('format');
  const [splitPosition, setSplitPosition] = useState<number>(50); // percentage for before/after slider
  const [viewMode, setViewMode] = useState<'split' | 'processed' | 'original'>('split');
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isExportingZip, setIsExportingZip] = useState<boolean>(false);

  const sliderContainerRef = useRef<HTMLDivElement>(null);
  const isDraggingSlider = useRef<boolean>(false);

  // Before/After split handle dragging
  const handleSliderMove = useCallback((clientX: number) => {
    if (!sliderContainerRef.current) return;
    const rect = sliderContainerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSplitPosition(percentage);
  }, []);

  const handleMouseDown = () => {
    isDraggingSlider.current = true;
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDraggingSlider.current) {
        handleSliderMove(e.clientX);
      }
    };
    const handleMouseUp = () => {
      isDraggingSlider.current = false;
    };
    const handleTouchMove = (e: TouchEvent) => {
      if (isDraggingSlider.current && e.touches.length > 0) {
        handleSliderMove(e.touches[0].clientX);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('touchmove', handleTouchMove);
    window.addEventListener('touchend', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleMouseUp);
    };
  }, [handleSliderMove]);

  if (!activeItem) {
    return null;
  }

  const settings = activeItem.settings;
  const sizeDelta = calculateSizeDelta(
    activeItem.originalSize,
    activeItem.processedSize || activeItem.originalSize
  );

  // Handlers for settings updates
  const updateSettingsPartial = (partial: Partial<typeof settings>) => {
    onUpdateSettings(activeItem.id, (prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        ...partial,
      },
    }));
  };

  const updateFiltersPartial = (filterPartial: Partial<typeof settings.filters>) => {
    onUpdateSettings(activeItem.id, (prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        filters: {
          ...prev.settings.filters,
          ...filterPartial,
        },
      },
    }));
  };

  const updateWatermarkPartial = (wmPartial: Partial<typeof settings.watermark>) => {
    onUpdateSettings(activeItem.id, (prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        watermark: {
          ...prev.settings.watermark,
          ...wmPartial,
        },
      },
    }));
  };

  // Preset aspect ratio application
  const applyAspectPreset = (preset: AspectRatioPreset) => {
    const origW = activeItem.originalWidth;
    const origH = activeItem.originalHeight;

    let targetW = origW;
    let targetH = origH;

    switch (preset) {
      case '1:1':
        targetW = Math.min(origW, origH);
        targetH = targetW;
        break;
      case '16:9':
        targetW = origW;
        targetH = Math.round((origW * 9) / 16);
        break;
      case '4:3':
        targetW = origW;
        targetH = Math.round((origW * 3) / 4);
        break;
      case '9:16':
        targetW = Math.round((origH * 9) / 16);
        targetH = origH;
        break;
      case '21:9':
        targetW = origW;
        targetH = Math.round((origW * 9) / 21);
        break;
      case 'ig-post':
        targetW = 1080;
        targetH = 1080;
        break;
      case 'ig-story':
        targetW = 1080;
        targetH = 1920;
        break;
      case 'yt-thumbnail':
        targetW = 1280;
        targetH = 720;
        break;
      case 'twitter-hdr':
        targetW = 1500;
        targetH = 500;
        break;
      case 'linkedin-bnr':
        targetW = 1584;
        targetH = 396;
        break;
      case 'original':
      default:
        targetW = origW;
        targetH = origH;
        break;
    }

    updateSettingsPartial({
      aspectPreset: preset,
      resizeWidth: targetW,
      resizeHeight: targetH,
    });
  };

  // Preset percentage scale
  const applyScalePercentage = (pct: number) => {
    const targetW = Math.round((activeItem.originalWidth * pct) / 100);
    const targetH = Math.round((activeItem.originalHeight * pct) / 100);
    updateSettingsPartial({
      resizeWidth: targetW,
      resizeHeight: targetH,
      aspectPreset: 'original',
    });
  };

  // Filter look presets
  const applyFilterPreset = (presetName: string) => {
    switch (presetName) {
      case 'noir':
        updateFiltersPartial({
          grayscale: 100,
          contrast: 135,
          brightness: 95,
          saturation: 0,
          sepia: 0,
          invert: 0,
          blur: 0,
          hueRotate: 0,
        });
        break;
      case 'vivid':
        updateFiltersPartial({
          contrast: 120,
          saturation: 140,
          brightness: 105,
          grayscale: 0,
          sepia: 0,
          invert: 0,
          blur: 0,
          hueRotate: 0,
        });
        break;
      case 'warm-amber':
        updateFiltersPartial({
          sepia: 40,
          brightness: 105,
          contrast: 110,
          saturation: 115,
          grayscale: 0,
          invert: 0,
          blur: 0,
          hueRotate: 15,
        });
        break;
      case 'cyber-matrix':
        updateFiltersPartial({
          contrast: 130,
          saturation: 150,
          brightness: 100,
          grayscale: 0,
          sepia: 0,
          invert: 0,
          blur: 0,
          hueRotate: 180,
        });
        break;
      case 'muted-editorial':
        updateFiltersPartial({
          contrast: 95,
          saturation: 75,
          brightness: 102,
          grayscale: 0,
          sepia: 15,
          invert: 0,
          blur: 0,
          hueRotate: 0,
        });
        break;
      case 'reset':
      default:
        updateFiltersPartial({
          brightness: 100,
          contrast: 100,
          saturation: 100,
          grayscale: 0,
          sepia: 0,
          blur: 0,
          invert: 0,
          hueRotate: 0,
        });
        break;
    }
  };

  // Download active item
  const handleDownloadActive = () => {
    if (!activeItem.processedBlob) return;
    const filename = getExportFilename(activeItem.name, settings.targetFormat);
    downloadBlob(activeItem.processedBlob, filename);
  };

  // Copy to clipboard
  const handleCopyToClipboard = async () => {
    if (!activeItem.processedBlob) return;
    try {
      // Browsers require image/png for clipboard write
      let pngBlob: Blob;
      if (activeItem.processedBlob.type === 'image/png') {
        pngBlob = activeItem.processedBlob;
      } else {
        // Render to canvas to get PNG
        const img = new Image();
        img.src = activeItem.processedUrl || activeItem.originalUrl;
        await new Promise((resolve) => (img.onload = resolve));
        const c = document.createElement('canvas');
        c.width = img.naturalWidth;
        c.height = img.naturalHeight;
        const ctx = c.getContext('2d');
        ctx?.drawImage(img, 0, 0);
        pngBlob = await new Promise<Blob>((res) => c.toBlob((b) => res(b!), 'image/png'));
      }

      await navigator.clipboard.write([
        new ClipboardItem({
          'image/png': pngBlob,
        }),
      ]);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    } catch {
      // Fallback: alert or ignore if blocked
    }
  };

  // Batch Zip download
  const handleBatchZip = async () => {
    setIsExportingZip(true);
    try {
      await exportAllAsZip(items);
    } finally {
      setIsExportingZip(false);
    }
  };

  return (
    <section id="workspace" className="py-8 md:py-12 bg-[#090D16] border-b border-slate-800/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Workspace Header Strip */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
              <span>Active Workspace</span>
              <span className="text-slate-500">·</span>
              <span>Hardware-Accelerated</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {activeItem.name}
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {items.length > 1 && (
              <button
                type="button"
                onClick={handleBatchZip}
                disabled={isExportingZip}
                className="flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-800/90 px-3.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:bg-slate-700 hover:text-white"
              >
                <Archive className="h-4 w-4 text-cyan-400" />
                <span>{isExportingZip ? 'Packaging ZIP...' : `Download All (${items.length}) ZIP`}</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleCopyToClipboard}
              className="flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-800/80 px-3.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:bg-slate-700 hover:text-white"
            >
              {isCopied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4 text-slate-300" />}
              <span>{isCopied ? 'Copied to Clipboard' : 'Copy Image'}</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadActive}
              disabled={activeItem.isProcessing || !activeItem.processedBlob}
              className="flex items-center gap-2 rounded-lg bg-cyan-500 px-4 py-2 text-xs font-semibold text-slate-950 transition-all hover:bg-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.3)] disabled:opacity-50"
            >
              <Download className="h-4 w-4" />
              <span>Download {settings.targetFormat.split('/')[1].toUpperCase()}</span>
            </button>
          </div>
        </div>

        {/* Multi-Image Batch Queue Strip */}
        {items.length > 1 && (
          <div className="mt-4 flex items-center gap-3 overflow-x-auto pb-2 border-b border-slate-800/50 scrollbar-thin">
            <span className="text-xs font-semibold text-slate-400 shrink-0 uppercase tracking-wider">
              Queue ({items.length}):
            </span>
            {items.map((item) => {
              const isActive = item.id === activeItem.id;
              return (
                <div
                  key={item.id}
                  onClick={() => onSelectActive(item.id)}
                  className={`group relative flex cursor-pointer items-center gap-2.5 rounded-lg border px-3 py-1.5 transition-all shrink-0 ${
                    isActive
                      ? 'border-cyan-400 bg-cyan-950/40 text-white shadow-sm'
                      : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <img
                    src={item.processedUrl || item.originalUrl}
                    alt={item.name}
                    className="h-6 w-6 rounded object-cover"
                  />
                  <div className="flex flex-col max-w-[130px] truncate text-left">
                    <span className="text-xs font-medium truncate">{item.name}</span>
                    <span className="text-[10px] font-mono tabular-nums text-slate-400">
                      {formatBytes(item.processedSize || item.originalSize)}
                    </span>
                  </div>
                  <button
                    type="button"
                    title="Remove item"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemoveItem(item.id);
                    }}
                    className="ml-1 rounded p-1 text-slate-500 hover:bg-slate-800 hover:text-rose-400 opacity-60 group-hover:opacity-100"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              );
            })}
            <button
              type="button"
              onClick={onClearAll}
              className="text-xs text-rose-400/80 hover:text-rose-300 ml-auto shrink-0 underline"
            >
              Clear All
            </button>
          </div>
        )}

        {/* Core Workspace Layout: Viewport (Left/Top) + Control Dock (Right/Bottom) */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Main Visual Viewport (7 Cols on desktop) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            {/* Viewport Toolbar Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-800/80 bg-[#0E1422] p-2.5">
              {/* View mode toggle */}
              <div className="flex items-center gap-1 bg-slate-900/90 rounded-lg p-1 border border-slate-800">
                <button
                  type="button"
                  onClick={() => setViewMode('split')}
                  className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    viewMode === 'split' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Columns className="h-3.5 w-3.5" />
                  <span>Split Comparison</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('processed')}
                  className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    viewMode === 'processed' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Eye className="h-3.5 w-3.5" />
                  <span>Processed Result</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('original')}
                  className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    viewMode === 'original' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Layers className="h-3.5 w-3.5" />
                  <span>Original Source</span>
                </button>
              </div>

              {/* Zoom Controls */}
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  title="Zoom Out"
                  onClick={() => setZoomLevel((z) => Math.max(0.5, parseFloat((z - 0.25).toFixed(2))))}
                  className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
                >
                  <ZoomOut className="h-4 w-4" />
                </button>
                <span className="text-xs font-mono tabular-nums text-slate-400 px-1">
                  {Math.round(zoomLevel * 100)}%
                </span>
                <button
                  type="button"
                  title="Zoom In"
                  onClick={() => setZoomLevel((z) => Math.min(3, parseFloat((z + 0.25).toFixed(2))))}
                  className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
                >
                  <ZoomIn className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  title="Reset Zoom"
                  onClick={() => setZoomLevel(1)}
                  className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white text-xs font-medium"
                >
                  <Maximize2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Interactive Viewport Canvas Box */}
            <div
              ref={sliderContainerRef}
              className="relative aspect-[16/10] w-full select-none overflow-hidden rounded-2xl border border-slate-800/80 transparency-checkerboard shadow-2xl flex items-center justify-center min-h-[380px]"
            >
              {/* Zoomable Container */}
              <div
                style={{ transform: `scale(${zoomLevel})`, transition: 'transform 0.15s ease-out' }}
                className="relative h-full w-full flex items-center justify-center pointer-events-none"
              >
                {/* 1. Original Layer (Always in background for split view or original view) */}
                {(viewMode === 'split' || viewMode === 'original') && (
                  <img
                    src={activeItem.originalUrl}
                    alt="Original"
                    className="absolute inset-0 h-full w-full object-contain"
                  />
                )}

                {/* 2. Processed Layer (Clipped when in split view) */}
                {(viewMode === 'split' || viewMode === 'processed') && (
                  <div
                    style={
                      viewMode === 'split'
                        ? { clipPath: `inset(0 0 0 ${splitPosition}%)` }
                        : undefined
                    }
                    className="absolute inset-0 h-full w-full flex items-center justify-center"
                  >
                    <img
                      src={activeItem.processedUrl || activeItem.originalUrl}
                      alt="Processed"
                      className="h-full w-full object-contain"
                    />
                  </div>
                )}
              </div>

              {/* Split view handle curtain */}
              {viewMode === 'split' && (
                <>
                  <div
                    style={{ left: `${splitPosition}%` }}
                    className="absolute top-0 bottom-0 w-0.5 bg-cyan-400 pointer-events-none z-20 shadow-[0_0_10px_rgba(6,182,212,0.8)]"
                  >
                    {/* Draggable knob handle */}
                    <div
                      onMouseDown={handleMouseDown}
                      onTouchStart={handleMouseDown}
                      className="pointer-events-auto absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex h-8 w-8 cursor-ew-resize items-center justify-center rounded-full border-2 border-white bg-slate-900 text-cyan-400 shadow-xl transition-transform hover:scale-110 active:scale-95"
                    >
                      <Columns className="h-4 w-4" />
                    </div>
                  </div>

                  {/* Split Labels */}
                  <div className="absolute top-3 left-3 z-10 rounded bg-slate-950/80 px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-300 backdrop-blur-sm border border-slate-800">
                    Original
                  </div>
                  <div className="absolute top-3 right-3 z-10 rounded bg-cyan-950/80 px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-cyan-300 backdrop-blur-sm border border-cyan-800/60">
                    {settings.targetFormat.split('/')[1].toUpperCase()}
                  </div>
                </>
              )}

              {/* Processing Spinner Overlay */}
              {activeItem.isProcessing && (
                <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs">
                  <div className="flex items-center gap-2 rounded-lg bg-slate-900 border border-slate-700 px-4 py-2.5 text-xs font-medium text-cyan-300 shadow-xl">
                    <RefreshCw className="h-4 w-4 animate-spin text-cyan-400" />
                    <span>Transcoding Canvas...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Dimension & File Size Telemetry HUD */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 rounded-xl border border-slate-800/80 bg-[#0E1422] p-4 text-xs font-mono">
              <div className="flex flex-col">
                <span className="text-slate-400 font-sans text-[11px] uppercase tracking-wider">Original Size</span>
                <span className="text-sm font-semibold text-slate-200 tabular-nums">
                  {formatBytes(activeItem.originalSize)}
                </span>
                <span className="text-[11px] text-slate-400 tabular-nums font-sans">
                  {activeItem.originalWidth} × {activeItem.originalHeight} px
                </span>
              </div>

              <div className="flex flex-col">
                <span className="text-slate-400 font-sans text-[11px] uppercase tracking-wider">Processed Output</span>
                <span className="text-sm font-semibold text-cyan-400 tabular-nums">
                  {formatBytes(activeItem.processedSize || activeItem.originalSize)}
                </span>
                <span className="text-[11px] text-slate-400 tabular-nums font-sans">
                  {activeItem.processedWidth || settings.resizeWidth} × {activeItem.processedHeight || settings.resizeHeight} px
                </span>
              </div>

              <div className="flex flex-col">
                <span className="text-slate-400 font-sans text-[11px] uppercase tracking-wider">Compression Delta</span>
                <span
                  className={`text-sm font-semibold tabular-nums ${
                    sizeDelta.saved ? 'text-emerald-400' : 'text-slate-300'
                  }`}
                >
                  {sizeDelta.text}
                </span>
                <span className="text-[11px] text-slate-400 font-sans">
                  {sizeDelta.saved
                    ? `Saved ${formatBytes(activeItem.originalSize - (activeItem.processedSize || 0))}`
                    : 'Lossless preservation'}
                </span>
              </div>

              <div className="flex flex-col">
                <span className="text-slate-400 font-sans text-[11px] uppercase tracking-wider">Target Format</span>
                <span className="text-sm font-semibold text-white uppercase">
                  {settings.targetFormat.split('/')[1]}
                </span>
                <span className="text-[11px] text-slate-400 font-sans">
                  Quality: {settings.quality}%
                </span>
              </div>
            </div>
          </div>

          {/* Interactive Control Dock (5 Cols on desktop) */}
          <div className="lg:col-span-5 rounded-2xl border border-slate-800/80 bg-[#0E1422] shadow-xl overflow-hidden">
            {/* Dock Tabs Header */}
            <div className="flex items-center border-b border-slate-800/80 bg-[#0A0F1A] overflow-x-auto scrollbar-none">
              <button
                type="button"
                onClick={() => setActiveTab('format')}
                className={`flex items-center gap-1.5 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors ${
                  activeTab === 'format'
                    ? 'border-cyan-400 text-cyan-400 bg-slate-900/60'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <FileCheck className="h-3.5 w-3.5" />
                <span>Format</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('resize')}
                className={`flex items-center gap-1.5 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors ${
                  activeTab === 'resize'
                    ? 'border-cyan-400 text-cyan-400 bg-slate-900/60'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Crop className="h-3.5 w-3.5" />
                <span>Resize</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('filters')}
                className={`flex items-center gap-1.5 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors ${
                  activeTab === 'filters'
                    ? 'border-cyan-400 text-cyan-400 bg-slate-900/60'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Sliders className="h-3.5 w-3.5" />
                <span>Adjust</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('transform')}
                className={`flex items-center gap-1.5 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors ${
                  activeTab === 'transform'
                    ? 'border-cyan-400 text-cyan-400 bg-slate-900/60'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <RotateCw className="h-3.5 w-3.5" />
                <span>Transform</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('watermark')}
                className={`flex items-center gap-1.5 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors ${
                  activeTab === 'watermark'
                    ? 'border-cyan-400 text-cyan-400 bg-slate-900/60'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Type className="h-3.5 w-3.5" />
                <span>Stamp</span>
              </button>
            </div>

            {/* Dock Tab Body */}
            <div className="p-5 flex flex-col gap-5 max-h-[580px] overflow-y-auto">
              {/* TAB 1: FORMAT & QUALITY */}
              {activeTab === 'format' && (
                <div className="flex flex-col gap-5">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-2 uppercase tracking-wider">
                      Select Target Format
                    </label>
                    <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                      {SUPPORTED_FORMAT_SPECS.map((spec) => {
                        const isSelected = settings.targetFormat === spec.format;
                        return (
                          <button
                            key={spec.format}
                            type="button"
                            onClick={() => updateSettingsPartial({ targetFormat: spec.format })}
                            className={`flex flex-col items-center justify-center p-2.5 rounded-lg border text-center transition-all ${
                              isSelected
                                ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.15)] font-bold'
                                : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                            }`}
                          >
                            <span className="text-sm font-semibold tracking-wide">{spec.label}</span>
                            <span className="text-[10px] text-slate-400 mt-0.5 truncate max-w-full">
                              {spec.extension.toUpperCase()}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Format description banner */}
                  <div className="rounded-lg bg-slate-900/80 border border-slate-800/80 p-3 text-xs text-slate-300">
                    <p className="font-semibold text-white mb-1">
                      {SUPPORTED_FORMAT_SPECS.find((s) => s.format === settings.targetFormat)?.fullName}
                    </p>
                    <p className="text-slate-400 text-[11px] leading-relaxed">
                      {SUPPORTED_FORMAT_SPECS.find((s) => s.format === settings.targetFormat)?.description}
                    </p>
                  </div>

                  {/* Quality Slider (for lossy formats) */}
                  {settings.targetFormat !== 'image/png' && settings.targetFormat !== 'image/svg+xml' && (
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between text-xs font-semibold">
                        <span className="text-slate-300">Compression Quality</span>
                        <span className="font-mono tabular-nums text-cyan-400 font-bold">
                          {settings.quality}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="100"
                        value={settings.quality}
                        onChange={(e) => updateSettingsPartial({ quality: parseInt(e.target.value, 10) })}
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                      />
                      <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                        <span>Max Compression (Smaller)</span>
                        <span>Balanced (85%)</span>
                        <span>Pristine (100%)</span>
                      </div>
                    </div>
                  )}

                  {/* Background Fill (Required for JPEG or transparent fill) */}
                  <div className="flex flex-col gap-2">
                    <label className="text-xs font-semibold text-slate-300 block">
                      Canvas Background Matte (For Transparent Pixels)
                    </label>
                    <div className="flex items-center gap-2">
                      {[
                        { label: 'Transparent', value: 'transparent' },
                        { label: 'White', value: '#FFFFFF' },
                        { label: 'Black', value: '#000000' },
                      ].map((bg) => (
                        <button
                          key={bg.value}
                          type="button"
                          onClick={() => updateSettingsPartial({ bgColor: bg.value })}
                          className={`flex-1 rounded-lg border py-2 text-xs font-medium transition-colors ${
                            settings.bgColor === bg.value
                              ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300'
                              : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          {bg.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: RESIZE & PRESETS */}
              {activeTab === 'resize' && (
                <div className="flex flex-col gap-5">
                  {/* Dimension Inputs */}
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-2 uppercase tracking-wider">
                      Output Resolution (Pixels)
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-[11px] text-slate-400 mb-1 block">Width</span>
                        <input
                          type="number"
                          min="1"
                          max="8000"
                          value={settings.resizeWidth}
                          onChange={(e) => {
                            const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                            if (settings.lockAspectRatio) {
                              const ratio = activeItem.originalHeight / activeItem.originalWidth;
                              updateSettingsPartial({
                                resizeWidth: val,
                                resizeHeight: Math.round(val * ratio),
                              });
                            } else {
                              updateSettingsPartial({ resizeWidth: val });
                            }
                          }}
                          className="w-full rounded-lg border border-slate-800 bg-slate-900/90 px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                        />
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 mb-1 block">Height</span>
                        <input
                          type="number"
                          min="1"
                          max="8000"
                          value={settings.resizeHeight}
                          onChange={(e) => {
                            const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                            if (settings.lockAspectRatio) {
                              const ratio = activeItem.originalWidth / activeItem.originalHeight;
                              updateSettingsPartial({
                                resizeHeight: val,
                                resizeWidth: Math.round(val * ratio),
                              });
                            } else {
                              updateSettingsPartial({ resizeHeight: val });
                            }
                          }}
                          className="w-full rounded-lg border border-slate-800 bg-slate-900/90 px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="mt-2 flex items-center justify-between">
                      <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-400">
                        <input
                          type="checkbox"
                          checked={settings.lockAspectRatio}
                          onChange={(e) => updateSettingsPartial({ lockAspectRatio: e.target.checked })}
                          className="h-3.5 w-3.5 rounded border-slate-700 bg-slate-900 text-cyan-400 accent-cyan-400"
                        />
                        <span>Lock Aspect Ratio</span>
                      </label>

                      <button
                        type="button"
                        onClick={() => applyAspectPreset('original')}
                        className="text-xs text-cyan-400/80 hover:text-cyan-300 font-mono"
                      >
                        Reset ({activeItem.originalWidth}×{activeItem.originalHeight})
                      </button>
                    </div>
                  </div>

                  {/* Percentage Scale Shortcuts */}
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-2">
                      Scaling Scale
                    </label>
                    <div className="grid grid-cols-5 gap-1.5 text-xs font-mono">
                      {[25, 50, 75, 100, 150].map((pct) => (
                        <button
                          key={pct}
                          type="button"
                          onClick={() => applyScalePercentage(pct)}
                          className="rounded-lg border border-slate-800 bg-slate-900/60 py-1.5 text-slate-300 hover:border-cyan-400/60 hover:text-white"
                        >
                          {pct}%
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Aspect Ratio & Social Presets */}
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-2">
                      Social & Platform Presets
                    </label>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {[
                        { label: 'Square (1:1)', id: '1:1' as AspectRatioPreset },
                        { label: 'Widescreen (16:9)', id: '16:9' as AspectRatioPreset },
                        { label: 'Standard (4:3)', id: '4:3' as AspectRatioPreset },
                        { label: 'Story (9:16)', id: '9:16' as AspectRatioPreset },
                        { label: 'Instagram (1080×1080)', id: 'ig-post' as AspectRatioPreset },
                        { label: 'YouTube (1280×720)', id: 'yt-thumbnail' as AspectRatioPreset },
                        { label: 'Twitter Header (1500×500)', id: 'twitter-hdr' as AspectRatioPreset },
                        { label: 'LinkedIn Banner (1584×396)', id: 'linkedin-bnr' as AspectRatioPreset },
                      ].map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => applyAspectPreset(preset.id)}
                          className={`rounded-lg border px-2.5 py-2 text-left transition-colors truncate ${
                            settings.aspectPreset === preset.id
                              ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300'
                              : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: COLOR ADJUSTMENTS & FILTERS */}
              {activeTab === 'filters' && (
                <div className="flex flex-col gap-5">
                  {/* Style Presets */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                        Color Presets
                      </label>
                      <button
                        type="button"
                        onClick={() => applyFilterPreset('reset')}
                        className="text-xs text-slate-400 hover:text-white"
                      >
                        Reset All
                      </button>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      {[
                        { label: 'Neutral', id: 'reset' },
                        { label: 'Film Noir', id: 'noir' },
                        { label: 'Vivid Pop', id: 'vivid' },
                        { label: 'Warm Sunset', id: 'warm-amber' },
                        { label: 'Cyber Matrix', id: 'cyber-matrix' },
                        { label: 'Editorial', id: 'muted-editorial' },
                      ].map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => applyFilterPreset(p.id)}
                          className="rounded-lg border border-slate-800 bg-slate-900/60 px-2 py-1.5 text-slate-300 hover:border-cyan-400/60 hover:text-white"
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Filter Sliders */}
                  <div className="flex flex-col gap-4">
                    {/* Brightness */}
                    <div>
                      <div className="flex justify-between text-xs font-medium mb-1">
                        <span className="text-slate-300">Brightness</span>
                        <span className="font-mono tabular-nums text-cyan-400">{settings.filters.brightness}%</span>
                      </div>
                      <input
                        type="range"
                        min="30"
                        max="180"
                        value={settings.filters.brightness}
                        onChange={(e) => updateFiltersPartial({ brightness: parseInt(e.target.value, 10) })}
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                      />
                    </div>

                    {/* Contrast */}
                    <div>
                      <div className="flex justify-between text-xs font-medium mb-1">
                        <span className="text-slate-300">Contrast</span>
                        <span className="font-mono tabular-nums text-cyan-400">{settings.filters.contrast}%</span>
                      </div>
                      <input
                        type="range"
                        min="30"
                        max="180"
                        value={settings.filters.contrast}
                        onChange={(e) => updateFiltersPartial({ contrast: parseInt(e.target.value, 10) })}
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                      />
                    </div>

                    {/* Saturation */}
                    <div>
                      <div className="flex justify-between text-xs font-medium mb-1">
                        <span className="text-slate-300">Saturation</span>
                        <span className="font-mono tabular-nums text-cyan-400">{settings.filters.saturation}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="200"
                        value={settings.filters.saturation}
                        onChange={(e) => updateFiltersPartial({ saturation: parseInt(e.target.value, 10) })}
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                      />
                    </div>

                    {/* Grayscale */}
                    <div>
                      <div className="flex justify-between text-xs font-medium mb-1">
                        <span className="text-slate-300">Grayscale</span>
                        <span className="font-mono tabular-nums text-cyan-400">{settings.filters.grayscale}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={settings.filters.grayscale}
                        onChange={(e) => updateFiltersPartial({ grayscale: parseInt(e.target.value, 10) })}
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                      />
                    </div>

                    {/* Sepia */}
                    <div>
                      <div className="flex justify-between text-xs font-medium mb-1">
                        <span className="text-slate-300">Sepia / Warmth</span>
                        <span className="font-mono tabular-nums text-cyan-400">{settings.filters.sepia}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={settings.filters.sepia}
                        onChange={(e) => updateFiltersPartial({ sepia: parseInt(e.target.value, 10) })}
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                      />
                    </div>

                    {/* Blur */}
                    <div>
                      <div className="flex justify-between text-xs font-medium mb-1">
                        <span className="text-slate-300">Soft Focus (Blur)</span>
                        <span className="font-mono tabular-nums text-cyan-400">{settings.filters.blur}px</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="16"
                        value={settings.filters.blur}
                        onChange={(e) => updateFiltersPartial({ blur: parseInt(e.target.value, 10) })}
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: TRANSFORM & BORDER */}
              {activeTab === 'transform' && (
                <div className="flex flex-col gap-5">
                  {/* Rotation Controls */}
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-2 uppercase tracking-wider">
                      Orientation & Rotation
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          updateSettingsPartial({
                            rotation: (settings.rotation + 90) % 360,
                          })
                        }
                        className="flex items-center justify-center gap-2 rounded-lg border border-slate-800 bg-slate-900/60 py-2.5 text-xs font-medium text-slate-200 hover:border-cyan-400/60 hover:text-white"
                      >
                        <RotateCw className="h-4 w-4 text-cyan-400" />
                        <span>Rotate +90°</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          updateSettingsPartial({
                            rotation: (settings.rotation - 90 + 360) % 360,
                          })
                        }
                        className="flex items-center justify-center gap-2 rounded-lg border border-slate-800 bg-slate-900/60 py-2.5 text-xs font-medium text-slate-200 hover:border-cyan-400/60 hover:text-white"
                      >
                        <RotateCcw className="h-4 w-4 text-cyan-400" />
                        <span>Rotate -90°</span>
                      </button>
                    </div>

                    <div className="mt-2 grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => updateSettingsPartial({ flipH: !settings.flipH })}
                        className={`flex items-center justify-center gap-2 rounded-lg border py-2.5 text-xs font-medium transition-colors ${
                          settings.flipH
                            ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300'
                            : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:text-white'
                        }`}
                      >
                        <FlipHorizontal className="h-4 w-4" />
                        <span>Flip Horizontal</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => updateSettingsPartial({ flipV: !settings.flipV })}
                        className={`flex items-center justify-center gap-2 rounded-lg border py-2.5 text-xs font-medium transition-colors ${
                          settings.flipV
                            ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300'
                            : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:text-white'
                        }`}
                      >
                        <FlipVertical className="h-4 w-4" />
                        <span>Flip Vertical</span>
                      </button>
                    </div>
                  </div>

                  {/* Corner Rounding */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-1">
                      <span className="text-slate-300">Rounded Corners</span>
                      <span className="font-mono tabular-nums text-cyan-400">{settings.borderRadius}px</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="120"
                      value={settings.borderRadius}
                      onChange={(e) => updateSettingsPartial({ borderRadius: parseInt(e.target.value, 10) })}
                      className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                    />
                    <div className="mt-2 flex gap-2">
                      {[0, 16, 32, 64].map((rad) => (
                        <button
                          key={rad}
                          type="button"
                          onClick={() => updateSettingsPartial({ borderRadius: rad })}
                          className="flex-1 rounded border border-slate-800 bg-slate-900/60 py-1 text-[11px] font-mono text-slate-400 hover:text-white"
                        >
                          {rad}px
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: WATERMARK & STAMP */}
              {activeTab === 'watermark' && (
                <div className="flex flex-col gap-5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                      Text Watermark Stamp
                    </label>
                    <input
                      type="checkbox"
                      checked={settings.watermark.enabled}
                      onChange={(e) => updateWatermarkPartial({ enabled: e.target.checked })}
                      className="h-4 w-4 rounded border-slate-700 bg-slate-900 text-cyan-400 accent-cyan-400"
                    />
                  </div>

                  {settings.watermark.enabled && (
                    <>
                      <div>
                        <span className="text-[11px] text-slate-400 mb-1 block">Custom Text</span>
                        <input
                          type="text"
                          value={settings.watermark.text}
                          onChange={(e) => updateWatermarkPartial({ text: e.target.value })}
                          placeholder="e.g. © 2026 LUMINA STUDIO"
                          className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-xs text-white focus:border-cyan-400 focus:outline-none"
                        />
                      </div>

                      {/* 9-Point Alignment Grid */}
                      <div>
                        <span className="text-[11px] text-slate-400 mb-1 block">Position Anchor</span>
                        <div className="grid grid-cols-3 gap-1.5 max-w-[180px]">
                          {[
                            'top-left',
                            'top-center',
                            'top-right',
                            'center-left',
                            'center',
                            'center-right',
                            'bottom-left',
                            'bottom-center',
                            'bottom-right',
                          ].map((pos) => (
                            <button
                              key={pos}
                              type="button"
                              onClick={() => updateWatermarkPartial({ position: pos as WatermarkPosition })}
                              className={`h-7 rounded border text-[10px] font-mono transition-colors ${
                                settings.watermark.position === pos
                                  ? 'border-cyan-400 bg-cyan-950/60 text-cyan-300 font-bold'
                                  : 'border-slate-800 bg-slate-900 text-slate-500 hover:text-white'
                              }`}
                            >
                              {pos.split('-').map((s) => s[0].toUpperCase()).join('')}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Font Size & Opacity */}
                      <div className="flex flex-col gap-3">
                        <div>
                          <div className="flex justify-between text-xs font-medium mb-1">
                            <span className="text-slate-300">Font Size</span>
                            <span className="font-mono tabular-nums text-cyan-400">{settings.watermark.fontSize}px</span>
                          </div>
                          <input
                            type="range"
                            min="14"
                            max="72"
                            value={settings.watermark.fontSize}
                            onChange={(e) => updateWatermarkPartial({ fontSize: parseInt(e.target.value, 10) })}
                            className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                          />
                        </div>

                        <div>
                          <div className="flex justify-between text-xs font-medium mb-1">
                            <span className="text-slate-300">Opacity</span>
                            <span className="font-mono tabular-nums text-cyan-400">{settings.watermark.opacity}%</span>
                          </div>
                          <input
                            type="range"
                            min="10"
                            max="100"
                            value={settings.watermark.opacity}
                            onChange={(e) => updateWatermarkPartial({ opacity: parseInt(e.target.value, 10) })}
                            className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-cyan-400"
                          />
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Quick Export Footer of Dock */}
            <div className="border-t border-slate-800/80 bg-[#0A0F1A] p-4 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                Processed locally in <strong className="text-cyan-400 font-mono">HTML5 Canvas</strong>
              </span>

              <button
                type="button"
                onClick={handleDownloadActive}
                className="flex items-center gap-1.5 rounded-lg bg-cyan-500 px-3.5 py-1.5 text-xs font-bold text-slate-950 transition-all hover:bg-cyan-400 active:scale-95"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Save File</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
