import React from 'react';
import { Lock, HardDrive, WifiOff, Cpu, ArrowRight } from 'lucide-react';

export const PrivacySection: React.FC = () => {
  return (
    <section id="privacy" className="py-16 md:py-24 bg-[#080B11] border-b border-slate-800/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl border border-slate-800 bg-[#0E1422] p-8 md:p-12 lg:p-16 relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 blur-[100px] rounded-full pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Left Column: Text & Guarantees */}
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-emerald-400 uppercase mb-4">
                <Lock className="h-3.5 w-3.5" />
                <span>Zero-Knowledge Architecture</span>
              </div>

              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight mb-4">
                Your Graphics Never Leave Your Hardware
              </h2>

              <p className="text-sm sm:text-base text-slate-400 leading-relaxed mb-6">
                Most online image converters upload your files to remote cloud servers, storing photos on third-party buckets where confidentiality is vulnerable. Lumina Studio executes 100% of encoding, compression, and mathematical matrix calculations inside your device’s GPU and CPU memory via standard W3C HTML5 APIs.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-800 text-xs">
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2 text-emerald-400 font-semibold">
                    <HardDrive className="h-4 w-4" />
                    <span>In-Memory Only</span>
                  </div>
                  <span className="text-slate-400">Garbage collected as soon as tab closes.</span>
                </div>

                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2 text-cyan-400 font-semibold">
                    <WifiOff className="h-4 w-4" />
                    <span>Offline Capable</span>
                  </div>
                  <span className="text-slate-400">Works completely without internet after loading.</span>
                </div>

                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2 text-indigo-400 font-semibold">
                    <Cpu className="h-4 w-4" />
                    <span>Hardware Native</span>
                  </div>
                  <span className="text-slate-400">Accelerated by your local GPU shaders.</span>
                </div>
              </div>
            </div>

            {/* Right Column: Architectural Flow Diagram */}
            <div className="lg:col-span-5 rounded-2xl border border-slate-800 bg-[#0A0E18] p-6 shadow-inner font-mono text-xs">
              <div className="text-slate-400 text-[11px] uppercase tracking-wider mb-4 pb-2 border-b border-slate-800 flex items-center justify-between">
                <span>Execution Pipeline</span>
                <span className="text-emerald-400 font-semibold">Encapsulated</span>
              </div>

              <div className="flex flex-col gap-3">
                {/* Step 1 */}
                <div className="flex items-center justify-between rounded-lg bg-slate-900/90 border border-slate-800 p-3">
                  <div>
                    <div className="text-white font-semibold">1. File Dropped</div>
                    <div className="text-[10px] text-slate-400">FileReader / Blob API</div>
                  </div>
                  <span className="text-emerald-400 text-[10px] font-sans">Local RAM</span>
                </div>

                <div className="flex justify-center text-slate-600">
                  <span className="text-xs">↓</span>
                </div>

                {/* Step 2 */}
                <div className="flex items-center justify-between rounded-lg bg-slate-900/90 border border-slate-800 p-3">
                  <div>
                    <div className="text-white font-semibold">2. Canvas 2D Pipeline</div>
                    <div className="text-[10px] text-slate-400">Resize, Color, Watermark</div>
                  </div>
                  <span className="text-cyan-400 text-[10px] font-sans">GPU Shaders</span>
                </div>

                <div className="flex justify-center text-slate-600">
                  <span className="text-xs">↓</span>
                </div>

                {/* Step 3 */}
                <div className="flex items-center justify-between rounded-lg bg-slate-900/90 border border-slate-800 p-3">
                  <div>
                    <div className="text-white font-semibold">3. Encoder toBlob()</div>
                    <div className="text-[10px] text-slate-400">WebP / AVIF / PNG / JPEG</div>
                  </div>
                  <span className="text-indigo-400 text-[10px] font-sans">Browser Engine</span>
                </div>

                <div className="flex justify-center text-slate-600">
                  <span className="text-xs">↓</span>
                </div>

                {/* Step 4 */}
                <div className="flex items-center justify-between rounded-lg bg-emerald-950/30 border border-emerald-800/40 p-3">
                  <div>
                    <div className="text-emerald-300 font-semibold">4. Instant Download</div>
                    <div className="text-[10px] text-emerald-400/80">URL.createObjectURL()</div>
                  </div>
                  <span className="text-emerald-400 text-[10px] font-sans">0 Bytes Sent</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
