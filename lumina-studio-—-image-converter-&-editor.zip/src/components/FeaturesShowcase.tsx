import React from 'react';
import { Cpu, ShieldCheck, Zap, Image as ImageIcon, SlidersHorizontal, Scale } from 'lucide-react';

export const FeaturesShowcase: React.FC = () => {
  return (
    <section id="capabilities" className="py-16 md:py-24 bg-[#080B11] border-b border-slate-800/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="text-xs font-semibold uppercase tracking-wider text-cyan-400 mb-2 flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
            <span>Architectural Capabilities</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3 [text-wrap:balance]">
            Engineered for High-Fidelity Client-Side Image Transformation
          </h2>
          <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
            Eliminate server-side conversion bottlenecks and privacy leaks. Lumina Studio executes all pixel math, color transformations, and format encoders directly inside your browser sandbox.
          </p>
        </div>

        {/* Asymmetric Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Format Transcoding (Span 2) */}
          <div className="md:col-span-2 rounded-2xl border border-slate-800/80 bg-[#0E1422] p-8 flex flex-col justify-between hover:border-slate-700 transition-colors">
            <div>
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider">
                  01. Multi-Format Transcoder
                </span>
                <div className="h-10 w-10 rounded-xl bg-cyan-950/60 border border-cyan-800/50 flex items-center justify-center text-cyan-400">
                  <Zap className="h-5 w-5" />
                </div>
              </div>

              <h3 className="text-xl font-bold text-white mb-2">
                Unified WebP, AVIF, PNG, JPEG & SVG Conversion
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                Transcode legacy graphics into modern high-efficiency web standards. Enjoy WebP transparency with 30% lower payload, explore AVIF next-generation compression, or export vector-wrapped SVG containers for design systems.
              </p>
            </div>

            {/* Tactical Format Grid Preview */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-800/80 text-xs">
              <div className="rounded-lg bg-slate-900/80 border border-slate-800 p-3">
                <div className="font-semibold text-white">WebP</div>
                <div className="text-[11px] text-slate-400 mt-1">25-35% lighter than JPG</div>
              </div>
              <div className="rounded-lg bg-slate-900/80 border border-slate-800 p-3">
                <div className="font-semibold text-white">AVIF</div>
                <div className="text-[11px] text-slate-400 mt-1">Next-gen HDR efficiency</div>
              </div>
              <div className="rounded-lg bg-slate-900/80 border border-slate-800 p-3">
                <div className="font-semibold text-white">PNG</div>
                <div className="text-[11px] text-slate-400 mt-1">Lossless alpha clarity</div>
              </div>
              <div className="rounded-lg bg-slate-900/80 border border-slate-800 p-3">
                <div className="font-semibold text-white">SVG</div>
                <div className="text-[11px] text-slate-400 mt-1">Scalable XML packaging</div>
              </div>
            </div>
          </div>

          {/* Card 2: 100% Client-Side Privacy */}
          <div className="rounded-2xl border border-slate-800/80 bg-[#0E1422] p-8 flex flex-col justify-between hover:border-slate-700 transition-colors">
            <div>
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider">
                  02. Absolute Privacy
                </span>
                <div className="h-10 w-10 rounded-xl bg-cyan-950/60 border border-cyan-800/50 flex items-center justify-center text-emerald-400">
                  <ShieldCheck className="h-5 w-5" />
                </div>
              </div>

              <h3 className="text-xl font-bold text-white mb-2">
                Zero Cloud Uploads
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed mb-4">
                Your images never leave your machine. Processing runs strictly within device memory via HTML5 Canvas and WebAssembly. No telemetry, no remote storage, and no network bandwidth consumption.
              </p>
            </div>

            <div className="pt-4 border-t border-slate-800/80 text-xs text-slate-400 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
              <span>Compliant with strict data residency requirements</span>
            </div>
          </div>

          {/* Card 3: Compression & Comparison */}
          <div className="rounded-2xl border border-slate-800/80 bg-[#0E1422] p-8 flex flex-col justify-between hover:border-slate-700 transition-colors">
            <div>
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider">
                  03. Perceptual Tuning
                </span>
                <div className="h-10 w-10 rounded-xl bg-cyan-950/60 border border-cyan-800/50 flex items-center justify-center text-cyan-400">
                  <Scale className="h-5 w-5" />
                </div>
              </div>

              <h3 className="text-xl font-bold text-white mb-2">
                Live Before / After Split
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed mb-4">
                Inspect compression artifacts, color shifts, and edge clarity in real-time with our interactive slider. Fine-tune quality percentages to strike the perfect balance between byte savings and visual excellence.
              </p>
            </div>

            <div className="pt-4 border-t border-slate-800/80 text-xs text-slate-400">
              <span className="font-mono text-cyan-400 font-bold tabular-nums">Average 75-85%</span> payload reduction on high-res camera originals.
            </div>
          </div>

          {/* Card 4: Precision Canvas Studio (Span 2) */}
          <div className="md:col-span-2 rounded-2xl border border-slate-800/80 bg-[#0E1422] p-8 flex flex-col justify-between hover:border-slate-700 transition-colors">
            <div>
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider">
                  04. Full Editing Suite
                </span>
                <div className="h-10 w-10 rounded-xl bg-cyan-950/60 border border-cyan-800/50 flex items-center justify-center text-cyan-400">
                  <SlidersHorizontal className="h-5 w-5" />
                </div>
              </div>

              <h3 className="text-xl font-bold text-white mb-2">
                Integrated Crop, Resize, Color Grade & Watermark
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                Complete your workflow in a single continuous session. Adjust exposure, contrast, saturation, and warmth; lock aspect ratios for social media standards (Instagram, YouTube, Twitter, LinkedIn); and stamp custom typographic watermarks with 9-point grid alignment.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-800/80 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
                <span>Social Dimension Presets</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
                <span>Hardware Filters (CSS3)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
                <span>90°/180° & Flip Geometry</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
                <span>Multi-File ZIP Archive</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
