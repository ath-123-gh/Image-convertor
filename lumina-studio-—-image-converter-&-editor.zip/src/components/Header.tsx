import React from 'react';
import { UploadCloud } from 'lucide-react';

interface HeaderProps {
  onOpenUpload: () => void;
  itemCount: number;
}

export const Header: React.FC<HeaderProps> = ({ onOpenUpload, itemCount }) => {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-800/80 bg-[#080B11]/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <a 
          href="/" 
          className="text-lg font-bold tracking-tight text-white transition-opacity hover:opacity-90 whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="inline-block h-2 w-2 rounded-sm bg-cyan-400"></span>
          <span>Lumina Studio</span>
        </a>

        {/* Zone 2: 5 single-line clean text navigation links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
          <a href="#workspace" className="hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0">
            Converter
          </a>
          <a href="#workspace" className="hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0">
            Studio Tools
          </a>
          <a href="#capabilities" className="hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0">
            Compression
          </a>
          <a href="#format-specs" className="hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0">
            Specs
          </a>
          <a href="#privacy" className="hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0">
            Privacy
          </a>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenUpload}
            className="flex items-center gap-2 rounded-lg bg-cyan-500 px-4 py-2 text-xs font-semibold text-slate-950 transition-all hover:bg-cyan-400 active:scale-95 whitespace-nowrap shrink-0 shadow-[0_0_20px_rgba(6,182,212,0.3)]"
          >
            <UploadCloud className="h-4 w-4" />
            <span>{itemCount > 0 ? `Add Images (${itemCount})` : 'Select Images'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
